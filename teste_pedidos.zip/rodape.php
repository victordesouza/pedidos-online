</div>
<p align="center">@ Copyright 2017 - Magazin Estofados, todos os direitos reservados.</p>
</body>
</html>
